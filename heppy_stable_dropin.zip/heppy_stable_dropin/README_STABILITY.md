# HEPPy preprocessing: stability and speed revision

This directory contains drop-in replacements for:

- `run_heppy_preprocessing.py`
- `snip_clips.py`
- `external/HEPPy/_preprocessing.py`

Back up the current files before replacing them. Regenerate the snipped EDFs: EDFs produced by the old `snip_clips.py` contain a four-byte annotation channel, which is too small even for the mandatory EDF+ timekeeping TAL and can therefore be malformed.

## What changed

### Native-crash containment and diagnosis

- Each EDF still runs in its own child process. A native access violation therefore loses one EDF, not the full batch.
- BLAS/OpenMP/Numba thread pools are forced to one thread by default. Set `HEPPY_NATIVE_THREADS=2` only after a stable single-thread run and benchmark it; do not run several EDF workers in parallel.
- Windows crash-dialog boxes are suppressed so a failed child cannot block the unattended batch.
- Every native-heavy stage emits `HEPPY_STAGE`, plus RSS if `psutil` is installed. The parent writes the last stage and the unsigned Windows exception code to the summary.
- Existing FIFs are opened and checked rather than trusted merely because a path exists.
- Raw FIF, ICA FIF, review CSV, summary CSV and snipped EDF output are written to a temporary sibling and atomically renamed on success. A killed process no longer presents a partial file as finished output.

### Correctness fixes

- Boolean ASR no longer becomes `cutoff=1`; `true` maps to 20 unless `asr_cutoff` is supplied.
- ASR is fitted and transformed at the same sampling frequency.
- The ICLabel cardiac class is `heart beat`, not `heart`; cardiac-retained output now actually retains that class.
- `both` mode respects ICA being disabled.
- The configured EEG band-pass is independent of PyPREP, and already-filtered data are not filtered again. The previous high-pass/low-pass metadata checks were reversed.
- EDF+ annotation capacity is calculated from the actual TAL payload instead of truncating annotations.
- `EDGE boundary` and `BAD boundary` annotations are written at every join between unrelated source periods.

### Runtime and peak-memory reductions

- PyPREP defaults to window-wise RANSAC (`channel_wise=false`), with annotation omission when the installed version supports it.
- The private PyPREP quantile monkey-patch is off by default.
- Per-snip PyPREP fits are off by default; a single patient-level fit avoids repeated setup and keeping many cleaned `Raw` objects alive. This is a speed/stability choice and should be validated for the intended analysis.
- ICA temporal decimation is selected to target approximately 100 Hz rather than using a fixed `decim=3`.
- The extra 1–100 Hz ICLabel copy is avoided when the data already meet the requirement.
- Non-EEG recombination copies only the auxiliary channels, not another complete `Raw` object.
- In `both` mode, ECG and spirometry are calculated once; the two ICA variants are created, saved and released sequentially.
- EDF snipping keeps source files open, seeks once per contiguous piece, uses buffered I/O and validates the final byte count.
- The snipper reports a per-patient source-record duplication factor, so overlapping pre-/postictal windows that inflate runtime are visible without silently changing the requested segments.

## Recommended initial `options_used.json` settings

Merge these keys into the existing options rather than replacing channel, montage or spirometry settings:

```json
{
  "target_sfreq": 256,
  "pyprep": true,
  "prep_ransac": false,
  "asr": false,
  "ica_iclabel": true,
  "filters": {
    "hp": 1.0,
    "lp": 100.0,
    "line_freqs": [50.0, 100.0]
  },
  "preprocessing_tuning": {
    "pyprep_channel_wise": false,
    "pyprep_max_chunk_size": 8,
    "pyprep_by_segment": false,
    "pyprep_safe_quantile_patch": false,
    "ica_fit_hz": 100.0,
    "iclabel_backend": "auto"
  }
}
```

Use a lower sampling rate only if it is compatible with the highest frequency required by the analysis. For a 40 Hz low-pass, 128–200 Hz may be sufficient; retaining activity to 100 Hz normally warrants a higher target such as 256 Hz.

ASR is disabled in the initial profile deliberately. In seizure data, treating non-stationary high-amplitude activity as an artefact can alter the signal of interest. Enable ASR only after validating its effect on the relevant endpoints. If enabled, use either:

```json
"asr": true,
"asr_cutoff": 20
```

or a numeric cutoff directly:

```json
"asr": 20
```

## First diagnostic run

From the project root:

```powershell
.\.venv\Scripts\python.exe run_heppy_preprocessing.py --self-check
.\.venv\Scripts\python.exe snip_clips.py --self-check
.\.venv\Scripts\python.exe run_heppy_preprocessing.py --limit 1 --redo --allow-pending
```

Then inspect:

- `heppy_output/logs/headless_preprocessing_summary.csv`
- `heppy_output/logs/headless_rows/*.log`
- `heppy_output/logs/preprocessing.tsv`

Typical `last_stage` interpretations:

| Last stage | Most likely subsystem |
|---|---|
| `imports_begin` | incompatible DLL/package stack during import |
| `read_raw` | malformed EDF/BDF or MNE reader/native decompression path |
| `resample` or `eeg_filter` | SciPy/NumPy FFT or memory pressure |
| `pyprep_fit` | PyPREP, especially RANSAC and recording size |
| `asr_fit` / `asr_transform` | ASRpy |
| `ica_fit` | Infomax/BLAS, recording duration or component count |
| `iclabel:auto`, `iclabel:torch`, `iclabel:onnx` | the selected neural-network runtime |
| `save_raw` / `save_ica` | disk, filesystem, antivirus/synchronisation or insufficient free space |

If the failure is at ICLabel, set `iclabel_backend` explicitly to the other installed backend (`onnx` or `torch`) and repeat one file. Do not install both backends merely for experimentation in the production environment; use a clean environment and lock it once stable.

## Environment checks

Run these in the same virtual environment used by the worker:

```powershell
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -c "import mne; mne.sys_info()"
.\.venv\Scripts\python.exe -c "import numpy, scipy, sklearn; from threadpoolctl import threadpool_info; import pprint; pprint.pp(threadpool_info())"
.\.venv\Scripts\python.exe -m pip freeze > requirements-working.txt
```

The thread-pool report should be examined for several OpenMP implementations loaded into one process. Also inspect **Windows Event Viewer → Windows Logs → Application → Application Error, Event ID 1000** at the crash time. The faulting module is much more informative than the two memory addresses. Examples include `mkl_rt.dll`, `libiomp5md.dll`, `onnxruntime.dll`, `torch_cpu.dll`, `ucrtbase.dll` or an EDF-reader dependency.

Keep the source, output and temporary directories on a local SSD during diagnosis. Leave the Windows page file system-managed and ensure there is enough free disk space for the input, an output FIF and an atomic temporary FIF simultaneously.

If the faulting module and `last_stage` vary randomly across otherwise identical runs, test RAM and storage rather than continuing to tune Python code.

## Validation performed here

- All three files pass `py_compile`.
- Both command-line self-checks pass.
- A synthetic MNE preprocessing smoke test passed, including replacement of an intentionally corrupt cached FIF, resampling/filtering, atomic single-output save, atomic dual-output save and cached re-open.
- A generated snipped EDF was successfully opened by MNE, with intact START/END, EDGE and BAD annotations.

The execution environment used for these checks does not contain PyPREP, ASRpy or MNE-ICALabel. Those branches were checked against their current public APIs and compile-tested, but they still need a one-file run in the actual virtual environment before a batch is launched.
